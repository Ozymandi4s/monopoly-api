### Basic Monopoly Game

To run this game

go into folder

run npm i 

access the endpoint: localhost:8080/api/v1/simular
